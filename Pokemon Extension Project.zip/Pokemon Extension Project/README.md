# THE POKEDEX

### This Pokedex is a collection of Pokemon cards in your browser.

#### >> How to use the Pokedex

1. Download the extension folder onto your computer.
2. Open the extensions section of your chrome browser.
3. Enable developer tools.
4. Click the "Load Unpacked" button and select the extension folder located on your computer.
5. The extension will be installed. Be sure to pin the extension to your taskbar.
6. Open the Pokedex by clicking the extension icon and a new uniqie pokemon card will be generated.
7. Close and reopen the extension to generate a new card.
